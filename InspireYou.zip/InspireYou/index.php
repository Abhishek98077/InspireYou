<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InspireYou</title>
    <!-- Link Swiper's CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
  </head>
  <body>
<!--Navbar Starts-->
<nav class="navbar navbar-expand-lg ">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.html"><img src="assets/logo1.png" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Online Training
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Web Development</a></li>
              <li><a class="dropdown-item" href="#">Python</a></li>
              <li><a class="dropdown-item" href="#">Java</a></li>
            </ul>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control rounded-0 form1 me-2" type="search" placeholder="Search Training..." aria-label="Search">
          <button class="btn btn2 rounded-0 me-5" type="submit"><i class="fas fa-search"></i></button>
        </form>
        <a href="contact.php"><button class="btn rounded-0 login me-5" type="submit">Contact us</button></a>

         <a href="login.php"><button class="btn rounded-0 login me-5" type="submit">Login</button></a>
         <!--<button onclick="myFunction()">Toggle dark mode</button>-->

         <a href="signup.php"><button class="btn rounded-0 login me-5" type="submit">Register</button></a>
         
      </div>
    </div>
  </nav>
<!--Navbar Ends-->

<div class="img-slider">
  <div class="slide active">
    <img src="assets/banner-1920 (1).png" alt="">
    <div class="info">
      <h2>Web Development</h2>
      <p>Master your self in building Websites</p>
    </div>
  </div>
  
  <div class="navigation">
    <div class="btn active"></div>
    
  </div>
</div>


<!--Demanding Courses-->
<div class="demand">
  <h2>Most Demanding</h2>
</div>
<!-- Swiper -->
<div class="swiper mySwiper">
  <div class="swiper-wrapper">
    <div class="swiper-slide">
      <img src="assets/webdev.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Web Development</h3>
        <p>Learn What Is Web Devlopment</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>

    <div class="swiper-slide">
      <img src="assets/webdpro.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Web Development Project</h3>
        <p>Learn How to Create Website</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>

    <div class="swiper-slide">
      <img src="assets/python.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Python Programing</h3>
        <p>Learn How to Create Website in Python</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>
    
    <div class="swiper-slide">
      <img src="assets/french.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>French Language</h3>
        <p>Learn How to Speak French</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="assets/spanish.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Spanish Language</h3>
        <p>Learn How to Speak Spanish</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>
    
  </div>
  <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
  <div class="swiper-pagination"></div>
</div>



<!--Programing Courses-->
<div class="demand">
  <h2>Programing Languages</h2>
</div>
<!-- Swiper -->
<div class="swiper mySwiper">
  <div class="swiper-wrapper">
    <div class="swiper-slide">
      <img src="assets/webdev.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Web Development</h3>
        <p>Learn What Is Web Devlopment</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>

    <div class="swiper-slide">
      <img src="assets/webdpro.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Web Development Project</h3>
        <p>Learn How to Create Website</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>

    <div class="swiper-slide">
      <img src="assets/python.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Python Programing</h3>
        <p>Learn How to Create Website in Python</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>
    
  </div>
  <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
  <div class="swiper-pagination"></div>
</div>

<div class="demand">
  <h2>Languages Course</h2>
</div>
<!-- Swiper -->
<div class="swiper mySwiper">
  <div class="swiper-wrapper">

   <div class="swiper-slide">
      <img src="assets/french.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>French Language</h3>
        <p>Learn How to Speak French</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
      </div>
    </div>
    <div class="swiper-slide">
      <img src="assets/spanish.png" alt="img">
      <span class="discount-tag">50% off</span>
      <div class="info1">
        <h3>Spanish Language</h3>
        <p>Learn How to Speak Spanish</p>
        <h6>Duration: <span class="duration">6</span> Weeks </h6>
        <a href="#">Know More</a>
    </div> 
  </div>
  </div>
  <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
  <div class="swiper-pagination"></div>
</div>




<!--Footer starts-->
<footer>
  <div class="content">
    <div class="top">
      <div class="logo-details">
        <a class="navbar-brand" href="index.html"><img src="assets/logo1.png" alt=""></a>
      </div>
      <div class="media-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
        <a href="#"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
    <div class="link-boxes">
      <ul class="box">
        <li class="link_name">Company</li>
        <li><a href="index.php">Home</a></li>
        <li><a href="contact.php">Contact us</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Services</li>
        <li><a href="#">Training</a></li>
        <li><a href="#">Placements</a></li>
        <li><a href="#">Internships</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Account</li>
        <li><a href="#">Profile</a></li>
        <li><a href="#">My account</a></li>
        <li><a href="#">Purchase</a></li>
      </ul>
      <ul class="box">
        <li class="link_name">Courses</li>
        <li><a href="#">Web Development</a></li>
        <li><a href="#">Python</a></li>
        <li><a href="#">French</a></li>
        <li><a href="#">Spanish</a></li>
      </ul>
      <ul class="box input-box">
        <li class="link_name">Subscribe</li>
        <li><input type="text" placeholder="Enter your email"></li>
        <li><input type="button" value="Subscribe"></li>
      </ul>
    </div>
  </div>
  <hr>
  <div class="bottom-details">
    <div class="bottom_text">
      <span class="copyright_text">Copyright © 2022&nbsp;&nbsp; <a href="index.html">InspireYou</a>All rights reserved</span>
      <span class="policy_terms">
        <a href="#">Privacy policy</a>
        <a href="#">Terms & condition</a>
      </span>
    </div>
  </div>
</footer>

  <!-- Swiper JS -->
  <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

  <script>
    var swiper = new Swiper(".mySwiper", {
      slidesPerView: 'auto',
      spaceBetween: 40,
      centeredSlides: true,
      grabCursor: true,
      loop: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  </script>

  <script src="assets/js/script.js"></script>
  </body>
</html>
